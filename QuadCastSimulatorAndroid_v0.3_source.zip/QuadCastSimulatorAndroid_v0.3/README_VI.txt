QUADCAST SIMULATOR ANDROID - SOURCE v0.3

Da them:
- Giao dien minh hoa micro voi den RGB chay mau.
- Input level meter (muc am luong dau vao).
- EQ 3 dai Bass/Mid/Treble dang tone shaping don gian.
- Gain 0.00x den 2.00x.
- Noise Gate theo nguong RMS.
- Short echo test co the dieu chinh.
- Nut noi Q keo tha va bang dieu khien nho.

Build:
1. Cai Android Studio va JDK 17.
2. Giai nen ZIP.
3. Mo thu muc QuadCastSimulatorAndroid_v0.3 trong Android Studio.
4. Cho Gradle sync, sau do Build > Build APK(s).
5. Cai APK debug tren Android 8.0 tro len.

Su dung an toan:
- Cam tai nghe co day truoc khi bat monitor.
- Bat dau voi gain 0.5x-1.0x, echo OFF, volume thap.
- Neu nghe re, feedback, am thanh qua to hoac meo, bam STOP.
- EQ trong prototype la tone shaping don gian, khong phai DSP chuan phong thu.
- Den RGB la hieu ung giao dien, khong dieu khien phan cung mic.
- Hinh micro la minh hoa giao dien, khong phai model 3D tuong tac.
- Menu noi can cap quyen "Display over other apps".
- Android thong thuong khong cho app nay tao virtual microphone cho Discord; Discord van su dung dau vao mic he thong.
- Chua the bao dam do tre thap tren moi dong may. Hay test voi volume nho.
