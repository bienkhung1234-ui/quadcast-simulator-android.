package com.example.quadcastsim;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public class MicGraphic extends View {
    private final Paint p = new Paint(3);
    private long start = System.currentTimeMillis();
    public MicGraphic(Context c) { super(c); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight(), cx=w/2f;
        c.drawColor(Color.TRANSPARENT);
        float hue=((System.currentTimeMillis()-start)/35f)%360f;
        p.setShader(new LinearGradient(cx-100,0,cx+100,h,
            Color.HSVToColor(new float[]{hue,0.9f,1f}),
            Color.HSVToColor(new float[]{(hue+130)%360,0.9f,1f}),Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        RectF body=new RectF(cx-43,h*0.10f,cx+43,h*0.68f);
        c.drawRoundRect(body,42,42,p);
        p.setShader(null); p.setColor(0xFF18181F);
        c.drawRoundRect(cx-34,h*0.15f,cx+34,h*0.63f,34,34,p);
        p.setColor(0xFF777780); p.setStrokeWidth(2);
        for(int i=0;i<7;i++) c.drawLine(cx-22,h*0.25f+i*13,cx+22,h*0.25f+i*13,p);
        p.setColor(0xFFBFC0C8); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(7);
        c.drawArc(cx-59,h*0.28f,cx+59,h*0.76f,0,180,false,p);
        c.drawLine(cx,h*0.76f,cx,h*0.88f,p);
        c.drawLine(cx-38,h*0.89f,cx+38,h*0.89f,p);
        p.setStyle(Paint.Style.FILL);
        postInvalidateDelayed(45);
    }
}
