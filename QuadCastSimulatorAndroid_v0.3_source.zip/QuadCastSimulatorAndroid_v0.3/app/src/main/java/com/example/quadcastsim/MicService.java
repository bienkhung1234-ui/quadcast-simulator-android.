package com.example.quadcastsim;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.media.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.util.Log;

public class MicService extends Service {
    private static final String CHANNEL="quadcast_mic";
    public static volatile float levelRms=0f;
    private volatile boolean running=false;
    private AudioRecord recorder;
    private AudioTrack player;
    private Thread audioThread;
    private WindowManager wm;
    private View bubble, panelView;
    private boolean panelOpen=false;

    @Override public void onCreate(){super.onCreate();createChannel();}
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"QuadCast microphone monitor",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Notification n;
        if(Build.VERSION.SDK_INT>=26)n=new Notification.Builder(this,CHANNEL).setContentTitle("QuadCast Simulator")
            .setContentText("Microphone monitor active").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build();
        else n=new Notification.Builder(this).setContentTitle("QuadCast Simulator").setContentText("Microphone monitor active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build();
        startForeground(7,n); startAudio(); showBubble(); return START_NOT_STICKY;
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private int overlayType(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}

    private void showBubble(){
        if(!Settings.canDrawOverlays(this)||bubble!=null)return;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        TextView b=new TextView(this); b.setText("Q"); b.setTextColor(Color.WHITE); b.setTextSize(19);
        b.setTypeface(null,Typeface.BOLD); b.setGravity(Gravity.CENTER); b.setBackgroundColor(0xFFE53935);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(54),dp(54),overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START;lp.x=20;lp.y=220;
        b.setOnTouchListener(new View.OnTouchListener(){
            float dx,dy;int sx,sy;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){dx=e.getRawX();dy=e.getRawY();sx=lp.x;sy=lp.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){lp.x=sx+(int)(e.getRawX()-dx);lp.y=sy+(int)(e.getRawY()-dy);wm.updateViewLayout(b,lp);return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){
                    if(Math.abs(e.getRawX()-dx)<10&&Math.abs(e.getRawY()-dy)<10)togglePanel(lp);
                    return true;
                }return true;
            }
        });
        bubble=b;try{wm.addView(bubble,lp);}catch(Exception e){bubble=null;}
    }
    private void togglePanel(WindowManager.LayoutParams anchor){
        if(panelOpen){try{wm.removeView(panelView);}catch(Exception ignored){}panelOpen=false;return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(8),dp(12),dp(8));box.setBackgroundColor(0xFF202027);
        TextView heading=new TextView(this);heading.setText("QUADCAST • LIVE");heading.setTextColor(Color.WHITE);heading.setTextSize(14);box.addView(heading);
        TextView meter=new TextView(this);meter.setText("Input level: "+(int)(levelRms*100)+"%");meter.setTextColor(0xFF80CBC4);box.addView(meter);
        Button stop=new Button(this);stop.setText("STOP MONITOR");stop.setOnClickListener(v->stopSelf());box.addView(stop);
        Button close=new Button(this);close.setText("CLOSE");close.setOnClickListener(v->{try{wm.removeView(panelView);}catch(Exception ignored){}panelOpen=false;});box.addView(close);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(220),WindowManager.LayoutParams.WRAP_CONTENT,overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.START;p.x=anchor.x;p.y=anchor.y+dp(60);panelView=box;
        try{wm.addView(panelView,p);panelOpen=true;}catch(Exception ignored){}
    }

    private void startAudio(){
        if(running)return;
        final int rate=48000;
        int inMin=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        int outMin=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
        if(inMin<=0||outMin<=0){stopSelf();return;}
        final int buffer=Math.max(Math.max(inMin,outMin),4096);
        try{
            AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
            am.setMode(AudioManager.MODE_IN_COMMUNICATION);
            am.setSpeakerphoneOn(false);
            recorder=new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,rate,AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,buffer);
            player=new AudioTrack(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),buffer,AudioTrack.MODE_STREAM,AudioManager.AUDIO_SESSION_ID_GENERATE);
            recorder.startRecording();player.play();running=true;
            audioThread=new Thread(()->{
                short[] data=new short[buffer/2];
                float[] echoDelay=new float[rate/12];int echoPos=0;
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);
                while(running){
                    int count=recorder.read(data,0,data.length);
                    if(count<=0)continue;
                    SharedPreferences sp=getSharedPreferences("quadcast",MODE_PRIVATE);
                    float gain=sp.getInt("gain",100)/100f;
                    float bass=(sp.getInt("bass",50)-50)/10f;
                    float mid=(sp.getInt("mid",50)-50)/10f;
                    float treble=(sp.getInt("treble",50)-50)/10f;
                    int gate=sp.getInt("gate",0);
                    float echo=sp.getInt("echo",0)/100f;
                    double sum=0;
                    for(int i=0;i<count;i++)sum+=(double)data[i]*data[i];
                    float rms=(float)(Math.sqrt(sum/Math.max(1,count))/32768.0);
                    levelRms=Math.min(1f,rms*3.5f);
                    boolean muted=gate>0&&rms*32768f<gate*18f;

                    // Lightweight three-band tone shaping: low/mid/high weighted shelf approximation.
                    float low=0, midState=0, previous=0;
                    for(int i=0;i<count;i++){
                        float x=data[i]/32768f;
                        low += 0.055f*(x-low);
                        midState += 0.32f*(x-midState);
                        float lowBand=low;
                        float midBand=midState-low;
                        float highBand=x-midState;
                        float shaped=lowBand*(float)Math.pow(10,bass/20f)
                            +midBand*(float)Math.pow(10,mid/20f)
                            +highBand*(float)Math.pow(10,treble/20f);
                        float y=muted?0f:shaped*gain;
                        float delayed=echoDelay[echoPos];
                        echoDelay[echoPos]=y+delayed*0.18f;
                        echoPos=(echoPos+1)%echoDelay.length;
                        y=y*(1f-echo*0.45f)+delayed*echo;
                        if(y>0.98f)y=0.98f;if(y< -0.98f)y=-0.98f;
                        data[i]=(short)(y*32767f);
                    }
                    player.write(data,0,count);
                }
            },"QuadCastDSP");
            audioThread.start();
        }catch(Exception e){Log.e("QuadCastSim","Audio failed",e);stopAudio();stopSelf();}
    }
    private void stopAudio(){
        running=false;levelRms=0;
        try{if(audioThread!=null)audioThread.join(500);}catch(InterruptedException ignored){}
        try{if(recorder!=null){recorder.stop();recorder.release();}}catch(Exception ignored){}
        try{if(player!=null){player.pause();player.flush();player.release();}}catch(Exception ignored){}
        recorder=null;player=null;audioThread=null;
        try{((AudioManager)getSystemService(AUDIO_SERVICE)).setMode(AudioManager.MODE_NORMAL);}catch(Exception ignored){}
    }
    @Override public void onDestroy(){
        stopAudio();
        try{if(panelView!=null&&wm!=null)wm.removeView(panelView);}catch(Exception ignored){}
        try{if(bubble!=null&&wm!=null)wm.removeView(bubble);}catch(Exception ignored){}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
