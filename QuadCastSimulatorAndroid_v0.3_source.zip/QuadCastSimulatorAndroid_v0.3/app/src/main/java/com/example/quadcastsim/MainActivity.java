package com.example.quadcastsim;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status, meterText;
    private ProgressBar meter;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable meterUpdater = new Runnable() {
        public void run() {
            int level = Math.min(100, (int)(MicService.levelRms * 100));
            if (meter != null) meter.setProgress(level);
            if (meterText != null) meterText.setText("INPUT LEVEL  " + level + "%");
            handler.postDelayed(this, 100);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("quadcast",MODE_PRIVATE);
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(22,22,22,28);
        page.setBackgroundColor(0xFF101014);
        scroll.addView(page);

        TextView title=text("HYPERX  /  QUADCAST",22,Color.WHITE);
        page.addView(title);
        page.addView(text("SIMULATOR • ANDROID • NO ROOT",11,0xFFAAAAAA));
        MicGraphic graphic=new MicGraphic(this);
        page.addView(graphic,new LinearLayout.LayoutParams(-1,dp(190)));

        status=text("MIC STATUS: STOPPED",15,0xFFFF7777);
        status.setPadding(0,10,0,8); page.addView(status);
        meterText=text("INPUT LEVEL  0%",12,Color.WHITE); page.addView(meterText);
        meter=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        meter.setMax(100); page.addView(meter,new LinearLayout.LayoutParams(-1,dp(12)));

        Button grant=button("GRANT MICROPHONE PERMISSION");
        grant.setOnClickListener(v->requestMic()); page.addView(grant);
        Button overlay=button("ENABLE FLOATING Q MENU");
        overlay.setOnClickListener(v->{
            if(!Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
            else toast("Floating menu permission is enabled");
        }); page.addView(overlay);

        Button start=button("START MIC MONITOR");
        start.setOnClickListener(v->startMonitor()); page.addView(start);
        Button stop=button("STOP MIC MONITOR");
        stop.setOnClickListener(v->{stopService(new Intent(this,MicService.class)); setStatus(false);}); page.addView(stop);

        section(page,"MIC GAIN");
        addSlider(page,"Output gain", "gain",200,100,"x100");
        section(page,"3-BAND EQUALIZER");
        addSlider(page,"Bass", "bass",120,50,"dB x10");
        addSlider(page,"Mid", "mid",120,50,"dB x10");
        addSlider(page,"Treble", "treble",120,50,"dB x10");
        section(page,"NOISE GATE");
        addSlider(page,"Gate threshold", "gate",1000,0,"level");
        section(page,"AMBIENCE / ECHO TEST");
        addSlider(page,"Short echo amount", "echo",35,0,"%");

        TextView warning=text("\\nTEST NOTES\\n• Plug in wired headphones before starting.\\n• Keep volume low for the first test.\\n• Echo is a short delayed copy, not a room reverb simulation.\\n• If you hear feedback, loud echo or distortion, stop monitoring.\\n• This app monitors locally; it does not create a virtual microphone for Discord.",13,0xFFCCCCCC);
        warning.setPadding(0,16,0,0); page.addView(warning);
        setContentView(scroll);
    }

    private void addSlider(LinearLayout parent,String label,String key,int max,int def,String suffix) {
        TextView name=text(label,13,0xFFDDDDDD); name.setPadding(0,12,0,0); parent.addView(name);
        TextView val=text("",12,0xFFFF7777); parent.addView(val);
        SeekBar bar=new SeekBar(this); bar.setMax(max); bar.setProgress(prefs.getInt(key,def)); parent.addView(bar);
        Runnable update=()->{
            int v=bar.getProgress(); prefs.edit().putInt(key,v).apply();
            if(key.equals("gain")) val.setText(String.format(java.util.Locale.US,"%.2fx",v/100f));
            else if(key.equals("bass")||key.equals("mid")||key.equals("treble")) val.setText(String.format(java.util.Locale.US,"%+.1f dB",(v-50)/10f));
            else val.setText(v==0?"OFF":v+" "+suffix);
        };
        update.run();
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean u){update.run();}
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
    }
    private void section(LinearLayout p,String s){TextView t=text(s,14,Color.WHITE);t.setPadding(0,22,0,4);p.addView(t);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void requestMic(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
        else toast("Microphone permission already granted");
    }
    private void startMonitor(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestMic();return;}
        Intent i=new Intent(this,MicService.class);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        setStatus(true);
    }
    private void setStatus(boolean on){status.setText(on?"MIC STATUS: MONITORING":"MIC STATUS: STOPPED");status.setTextColor(on?0xFF66DD88:0xFFFF7777);}
    @Override protected void onResume(){super.onResume();handler.post(meterUpdater);}
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(meterUpdater);}
}
